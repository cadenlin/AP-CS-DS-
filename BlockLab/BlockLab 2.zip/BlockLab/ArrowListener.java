/**
* DO NOT MODIFY THIS CODE
* There are no user serviceable components.  Any changes will void your warranty.
*/
public interface ArrowListener
{
	void upPressed();
	void downPressed();
	void leftPressed();
	void rightPressed();
}